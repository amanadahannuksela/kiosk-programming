var sort="undefined";

function askHelp(){
	var value = confirm("Need help? Our customer servan't will be there to help you as soon as possible!");
	if(value){
		window.location.href="https://www.google.com";
	}
}
function popupJuice(){
	sort="juice";
	document.getElementById('pWindow').style.display='block';
}

function popupSmoothie(){
	sort="smoothie";
	document.getElementById('pWindow').style.display='block';
}

function cancel(){
	sort="undefined";
	document.getElementById('pWindow').style.display='none';
}

function gonext(size){
	if(sort=="undefined"){
		alert("Something went wrong! Sort is not defined.");
	} else {
		var url="/diy?size="+size+"?sort="+sort;
		window.location.href=url;
	}
}
