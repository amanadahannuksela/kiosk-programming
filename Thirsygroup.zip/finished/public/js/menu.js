/*jslint es5:true, indent: 2 */
/*global sharedVueStuff, Vue, socket */
'use strict';

function getImgPath(item){
	return "img/"+item.ingredient_id+"_"+item.ingredient_en+".png";
}

//10/10 coding here
var ordernr=0;
function getOrderNumber() {
  // It's probably not a good idea to generate a random order number, client-side. 
  // A better idea would be to let the server decide.
  ordernr++;
  return "#" + ordernr;
}

Vue.component('ingredient', {
  props: ['item', 'type', 'lang'],
  template: ' <div class="ingredient">\
                  <label>\
                    <button v-on:click="incrementCounter">{{ counter }}</button>\
                    {{item["ingredient_"+ lang]}} ({{ (type=="smoothie") ? item.vol_smoothie:item.vol_juice }} ml), {{item.selling_price}}:-, {{item.stock}} pcs  <img v-bind:src=getImgPath(item) :width="100" :height="100"></img>\
                  </label>\
              </div>',
  data: function () {
    return {
      counter: 0
    };
  },
  methods: {
    incrementCounter: function () {
      this.counter += 1;
      this.$emit('increment');
    },
    resetCounter: function () {
      this.counter = 0;
    },
	getImgPath: function(item){
		return "img/"+item.ingredient_id+"_"+item.ingredient_en+".png";
	}
  }
});


//this should be put in a shared object
var chosenIngredients=[];
var volume=0;
var price=0;
var type='';

var vm = new Vue({
  el: '#ingredientlist',
  mixins: [sharedVueStuff], // include stuff that is used both in the ordering system and in the kitchen
  data: {
	sort:'liquids'
  },
  methods: {
    addToChosen: function (item, type) {
      chosenIngredients.push(item);
      type = type;
      if (type === "smoothie") {
        volume += +item.vol_smoothie;
      } else if (type === "juice") {
        volume += +item.vol_juice;
      }
      price += +item.selling_price;
	  vm4.$refs["chosen"+chosenIngredients.length+"img"].src=getImgPath(item);
    },
	getImgPath: function(item){
		return "img/"+item.ingredient_id+"_"+item.ingredient_en+".png";
	}
  }
});

var vm2 = new Vue({
	el:'#categories',
	mixins:[sharedVueStuff],
	data:{
		sort:"liquids"
	},
	methods:{
		changeSort: function(newsort){
			vm.sort=newsort;
			this.$refs["liquids"].style="background-color:#ffc107";
			this.$refs["fruit"].style="background-color:#ffc107";
			this.$refs["veggies"].style="background-color:#ffc107";
			this.$refs["other"].style="background-color:#ffc107";
			this.$refs[newsort].style="background-color:#fff000";
		}
	}
});

var vm3 = new Vue({
  el: '#cart',
  mixins: [sharedVueStuff], // include stuff that is used both in the ordering system and in the kitchen
  methods: {
    placeOrder: function () {
      var i,
      //Wrap the order in an object
        order = {
          ingredients: chosenIngredients,
          volume: volume,
          type: type,
          price: price
        };
      // make use of socket.io's magic to send the stuff to the kitchen via the server (app.js)
      socket.emit('order', {orderId: getOrderNumber(), order: order});
      //set all counters to 0. Notice the use of $refs
      for (i = 0; i < this.$refs.ingredient.length; i += 1) {
        this.$refs.ingredient[i].resetCounter();
      }
      volume = 0;
      price = 0;
      type = '';
      chosenIngredients = [];
	  vm4.$refs["chosen1img"].src="img/substitue.png";
	  vm4.$refs["chosen2img"].src="img/substitue.png";
	  vm4.$refs["chosen3img"].src="img/substitue.png";
	  vm4.$refs["chosen4img"].src="img/substitue.png";
	  vm4.$refs["chosen5img"].src="img/substitue.png";
    },
	getImgPath: function(item){
		return "img/"+item.ingredient_id+"_"+item.ingredient_en+".png";
	}
  }
});

var vm4 = new Vue({
	el:'#choicetable',
	mixins:[sharedVueStuff],
	methods:{
		addToChosen: function (item, type) {
			chosenIngredients.push(item);
			type = type;
			if (type === "smoothie") {
				volume += +item.vol_smoothie;
			} else if (type === "juice") {
				volume += +item.vol_juice;
			}
			price += +item.selling_price;
			this.$refs["chosen"+chosenIngredients.length+"img"].src=getImgPath(item);
		}
	},
	getImgPath: function(item){
		return "img/"+item.ingredient_id+"_"+item.ingredient_en+".png";
	}
});