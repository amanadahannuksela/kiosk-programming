/*jslint es5:true, indent: 2 */
/*global sharedVueStuff, Vue, socket */
'use strict';

function backConfirmation(){
	var value = confirm("If you leave now, you will lose your cart. Are you sure you want to leave?");
	if(value){
		window.location.href="homemenu.html";
	}
}
function askHelp(){
	var value = confirm("Need help? Our customer servan't will help you as soon as possible!");
	if(value){
		window.location.href="https://www.google.com";
	}
}



//ingredient object for vue
Vue.component('ingredient', {
  props: ['item', 'type', 'lang'],
  template: ' <div class="ingredient">\
                  <label>\
                    <button v-on:click="chooseItem"> + </button>\
                    {{item["ingredient_"+ lang]}} ({{ (type=="smoothie") ? item.vol_smoothie:item.vol_juice }} ml), {{item.selling_price}}:-, {{item.stock}} pcs  <img v-bind:src=getImgPath(item) :width="100" :height="100"></img>\
                  </label>\
              </div>',
  methods: {
	getImgPath: function(item){
		return "img/"+item.ingredient_id+"_"+item.ingredient_en+".png";
	},
	chooseItem: function(){
		this.$emit('choose');
	}
  }
});


//ingredientlist vue
var vm = new Vue({
  el: '#mainid',
  mixins: [sharedVueStuff], // include stuff that is used both in the ordering system and in the kitchen
  data: {
	ingredientSort:'liquids',
	drinkSort:'smoothie',
	type:0,
	drinks:[],
	chosenIngredients:[],
	glassSize:"M",
	message: "sample text",
	menuShown: false,
	registerShown: false,
	preJuiceShown: false,
	preSmoothieShown: false,
	DIYShown: true,
	showPopup: false,
	showPopupLarge: true,
	showPopupMedium: true,
	tba:[]
  },
  methods: {
    addToOrder: function () {
	   var drink = {
		   ingredients: this.chosenIngredients,
		   volume: 0,
		   price: 0
	   };
	   switch(this.glassSize){
		   case "S": drink.volume=330; drink.price=300; break;
		   case "M": drink.volume=500; drink.price=500; break;
		   case "L": drink.volume=850; drink.price=750; break;
	   }
	   this.drinks.push(drink);
	   this.chosenIngredients=[];
	},
	getImagePath: function(item){
		return "img/"+item.ingredient_id+"_"+item.ingredient_en+".png";
	},
	getGlassPath: function(){
		return "img/glass"+this.glassSize+this.chosenIngredients.length+".png";
	},
	addToChosen: function(item, type){
		if( (this.chosenIngredients.length==3 && this.glassSize=="S") ||
			(this.chosenIngredients.length==4 && this.glassSize=="M") ||
			(this.chosenIngredients.length==5 && this.glassSize=="L")){
				this.showSizePopup();
				this.tba.push(item);
		} else {
			this.chosenIngredients.push(item);
		}
	},
	changeSort: function(newsort){
		this.ingredientSort=newsort;
		this.$refs["liquids"].style="background-color:#ffc107";
		this.$refs["fruit"].style="background-color:#ffc107";
		this.$refs["veggies"].style="background-color:#ffc107";
		this.$refs["other"].style="background-color:#ffc107";
		this.$refs[newsort].style="background-color:#fff000";
	},
	placeOrder: function () {
		if(this.drinks.length==0){
			return;
		}
		var i,
		//Wrap the order in an object
		order = {
			drinks: this.drinks,
			volume: 0,
			type: 0,
			price: 0,
		};
		// make use of socket.io's magic to send the stuff to the kitchen via the server (app.js)
		socket.emit('order', {order: order});
		//set all counters to 0. Notice the use of $refs
		for(var drink in this.drinks){
			order.price += drink.price;
			order.volume += drink.volume;
		}
		this.chosenIngredients = [];
		this.drinks = [];
    },
	showMenu: function(){
		menuShown = true;
		registerShown = false;
		preJuiceShown = false;
		preSmoothieShown = false;
		DIYShown = false;
	},
	showRegister: function(){
		menuShown = false;
		registerShown = true;
		preJuiceShown = false;
		preSmoothieShown = false;
		DIYShown = false;
	},
	showJuice: function(){
		menuShown = false;
		registerShown = false;
		preJuiceShown = true;
		preSmoothieShown = false;
		DIYShown = false;
	},
	showSmoothie: function(){
		menuShown = false;
		registerShown = false;
		preJuiceShown = false;
		preSmoothieShown = true;
		DIYShown = false;
	},
	showDIY: function(){
		menuShown = false;
		registerShown = false;
		preJuiceShown = false;
		preSmoothieShown = false;
		DIYShown = true;
	},
	showSizePopup(){
		var popup = document.getElementById("sizeChangePopup");
		switch(this.glassSize){
			case "S":	this.message = "You have already added the maximum ingredients we can fit in a large "+this.drinkSort+". To add another ingredient, you can upgrade this drink to a medium or large drink. Alternatively, order another drink.";
						this.showPopupMedium = true; this.showPopupLarge = true; break;
			case "M": 	this.message = "You have already added the maximum ingredients we can fit in a large "+this.drinkSort+". To add another ingredient, you can upgrade this drink to a large drink. Alternatively, order another drink.";
						this.showPopupMedium = false; this.showPopupLarge = true; break;
			case "L": 	this.message = "You have already added the maximum ingredients we can fit in a large "+this.drinkSort+". You can remove an ingredient to add another, or make another drink.";
						this.showPopupMedium = false; this.showPopupLarge = false; break;
			default: 	this.message = "Something went wrong, please contact the devs at w3d0nTc4are@gmail.com";
		}
		this.showPopup = true;
	},
	popupLarge(){
		this.glassSize = "L";
		this.chosenIngredients.push(this.tba.pop());
		this.tba=[];
		this.showPopup=false;
	},
	popupMedium(){
		this.glassSize = "M";
		this.chosenIngredients.push(this.tba.pop());
		this.tba=[];
		this.showPopup=false;
	},
	popupCancel(){
		this.allowed=false;
		this.tba=[];
		this.showPopup=false;
	}
  }
});


